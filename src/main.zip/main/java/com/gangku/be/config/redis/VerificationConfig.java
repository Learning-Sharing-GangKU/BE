package com.gangku.be.config.redis;

public class VerificationConfig {

}
